#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <assert.h>

int main(int argc, char* argv[]) {
	// I understand there is literally nothing completed here.
	// I have two other summer courses that have exams that
	// I wanted to focus on first. For the peer reviewing
	// this code, I will do my best to give you a worthwhile
	// review, and hopefully my lack of code makes things
	// easier for you.
	FILE *file;
	file = fopen("
	return EXIT_SUCCESS;
}
/* vim: set tabstop=4 shiftwidth=4 fileencoding=utf-8 noexpandtab: */
