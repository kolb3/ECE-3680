#include "sample.h"

int main()
{

    if (
          verifying e condition //pseudo, there was failure while getting the options
            )


    FILE *fpr = fopen("operations_input_file.txt", "r");

    /* Ensure FILE1.C opened successfully*/
    int ar[20];
    char ch[20];
    if (fpr == NULL)
    {
        int i=-1;
        fprintf(stdout, "%d\n",i);
        return exit(EXIT EXIT_FAILURE)
    } else
    {
    while (fread(&val, sizeof(int), 1, fpr) == 1 ))
        {
    ar[i]=fread(&val, sizeof(int), 1, fpr);
    ch[i]=fread(&val, sizeof(char), 1, fpr);
        }
        fpr.close;
    }
    while(I=1) {
        if (ch[i] == 'i')
            insert(
        struct *node, ar[i])
        if (ch[i] == 'd')
            delete(
        struct *node, ar[i])
        if (ar[i] == null)
            break;
        i++;
    }


    }
}