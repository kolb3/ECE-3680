#ifndef __SEQUENCE_H__
#define __SEQUENCE_H__

long *Generate_2p3q_Seq(int length, int *seq_size);

#endif

