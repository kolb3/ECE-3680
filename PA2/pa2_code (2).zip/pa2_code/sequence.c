#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <limits.h>
#include "sequence.h"
#include "shell_array.h"
#include "shell_list.h"

long * Generate_2p3q_Seq(int length, int * seq_size)
{
  
}
