#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <limits.h>
#include "sequence.h"
#include "shell_array.h"
#include "shell_list.h"


//Well hopefully I can update this because of a shitty fluke with GITHUHB DESKTOP all of my work got deleted, so as of rightn ow I have nothing which is bullshit so below are my questions that I had previously asked hopefully this will make life a lot easier
//in main we call the open file which saves everything and returns the adress of a long int, then we call a sort which calls generate, this is where my questions start
//the n_comp variable is that supposed to be passed by address purely so we can count the number of times things have been evaluated?
//the other question I have is on the generate function, am I just supposed to create a pratt gap sequence of elements that are less than n, n being the totall number of elements from the file?
//then this array of gap sequence elements 1,2,3,4,6,8,9 etc are supposed to be set as longs and then those will give us the key k for the shells in the shell sort.
int main()
{
  int num;
  int * array = NULL;


}
